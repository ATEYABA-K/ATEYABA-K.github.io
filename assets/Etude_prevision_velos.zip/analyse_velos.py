"""Prévision à J+1 des locations quotidiennes, Capital Bikeshare (UCI, CC BY 4.0)."""
import argparse
import csv
import io
import json
import math
import urllib.request
import zipfile
from datetime import date, timedelta
from pathlib import Path

import numpy as np

SOURCE = "https://archive.ics.uci.edu/static/public/275/bike+sharing+dataset.zip"
DOI = "https://doi.org/10.24432/C5W894"


def load_days(archive):
    with zipfile.ZipFile(archive) as zf, zf.open("day.csv") as source:
        rows = list(csv.DictReader(io.TextIOWrapper(source, encoding="utf-8-sig")))
    days = [date.fromisoformat(row["dteday"]) for row in rows]
    expected = [date(2011, 1, 1) + timedelta(days=i) for i in range(731)]
    if days != expected:
        raise ValueError("La série doit contenir chaque journée de 2011 et 2012, une seule fois.")
    counts = np.array([int(row["cnt"]) for row in rows])
    for row, count in zip(rows, counts):
        if count < 0 or count != int(row["casual"]) + int(row["registered"]):
            raise ValueError("Total de locations incohérent pour " + row["dteday"])
    return days, counts, np.array([int(row["holiday"]) for row in rows])


def formulate(days, counts, holidays):
    """Variables connues avant le jour cible, dans une prévision glissante."""
    rows = []
    for i in range(14, len(days)):
        day = days[i]
        angle = 2 * math.pi * (day - date(2011, 1, 1)).days / 365.25
        rows.append([
            1, i / 365.25, math.sin(angle), math.cos(angle), holidays[i],
            *(int(day.weekday() == weekday) for weekday in range(1, 7)),
            counts[i - 1], counts[i - 7], counts[i - 14],
        ])
    return np.array(rows), counts[14:], counts[7:-7], np.array(days[14:])


def score(actual, predicted, dates):
    errors = predicted - actual
    week_end = np.array([day.weekday() >= 5 for day in dates])
    return {
        "mae": float(np.abs(errors).mean()),
        "rmse": float(np.sqrt(np.square(errors).mean())),
        "bias": float(errors.mean()),
        "mae_weekday": float(np.abs(errors[~week_end]).mean()),
        "mae_weekend": float(np.abs(errors[week_end]).mean()),
        "n_weekday": int((~week_end).sum()),
        "n_weekend": int(week_end.sum()),
    }


def evaluate(x, y, weekly, dates, fit_end, end):
    train = dates < fit_end
    target = (dates >= fit_end) & (dates < end)
    coefficients = np.linalg.lstsq(x[train], y[train], rcond=None)[0]
    predicted = np.maximum(0, x[target] @ coefficients)
    return {
        "start": str(dates[target][0]), "end": str(dates[target][-1]),
        "train_rows": int(train.sum()), "n": int(target.sum()),
        "weekly": score(y[target], weekly[target], dates[target]),
        "linear": score(y[target], predicted, dates[target]),
    }, zip(dates[target], y[target], weekly[target], predicted)


def run(archive, destination):
    days, counts, holidays = load_days(archive)
    x, y, weekly, dates = formulate(days, counts, holidays)
    validation, _ = evaluate(x, y, weekly, dates, date(2012, 1, 1), date(2012, 7, 1))
    test, traces = evaluate(x, y, weekly, dates, date(2012, 7, 1), date(2013, 1, 1))
    destination.mkdir(parents=True, exist_ok=True)
    records = list(traces)
    with (destination / "predictions.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["date", "observe", "reference_j7", "regression"])
        writer.writerows((day, actual, baseline, round(model, 2))
                         for day, actual, baseline, model in records)
    monthly = {}
    for month in range(7, 13):
        selected = [row for row in records if row[0].month == month]
        monthly[month] = {
            "weekly": sum(abs(a - b) for _, a, b, _ in selected) / len(selected),
            "linear": sum(abs(a - m) for _, a, _, m in selected) / len(selected),
        }
    report = {"source": DOI, "observations": len(days), "validation": validation,
              "test": test, "monthly_test_mae": monthly}
    (destination / "metrics.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, help="Archive UCI locale, sinon téléchargement UCI.")
    parser.add_argument("--output", type=Path, default=Path("resultats"))
    args = parser.parse_args()
    if args.archive:
        archive = args.archive
    else:
        with urllib.request.urlopen(SOURCE, timeout=45) as response:
            archive = io.BytesIO(response.read())
    print(json.dumps(run(archive, args.output), indent=2))

