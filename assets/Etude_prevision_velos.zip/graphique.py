"""Graphique des erreurs mensuelles à partir de metrics.json."""
import argparse
import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

def graph(metrics, output):
    width, height = 940, 432
    image = Image.new("RGB", (width, height), "#fffdf8")
    draw = ImageDraw.Draw(image)
    font_path = Path("/System/Library/Fonts/Supplemental/Arial.ttf")
    try:
        font = ImageFont.truetype(str(font_path), 23)
        medium = ImageFont.truetype(str(font_path), 25)
    except OSError:
        font = ImageFont.load_default(size=23)
        medium = ImageFont.load_default(size=25)
    draw.text((26, 20), "Erreur moyenne par mois sur le jeu de test", font=medium, fill="#1d2073")
    x_start, y_top, y_floor, x_end = 83, 76, 320, 915
    for tick in range(0, 1601, 400):
        y = y_floor - tick * (y_floor - y_top) / 1600
        draw.line((x_start, y, x_end, y), fill="#d7ded5", width=2)
        draw.text((68, y), str(tick), anchor="rm", font=font, fill="#4d605b")
    labels = ("Juil.", "Août", "Sept.", "Oct.", "Nov.", "Déc.")
    for i, (month, label) in enumerate(zip(range(7, 13), labels)):
        values = metrics["monthly_test_mae"][str(month)]
        x = 145 + 137 * i
        for offset, field, color in ((-33, "weekly", "#383dce"), (2, "linear", "#ce5337")):
            y = y_floor - values[field] * (y_floor - y_top) / 1600
            draw.rounded_rectangle((x + offset, y, x + offset + 32, y_floor), 3, fill=color)
        draw.text((x, 339), label, anchor="mt", font=font, fill="#283e39")
    draw.rectangle((92, 385, 117, 404), fill="#383dce")
    draw.text((130, 394), "Même jour, semaine précédente", anchor="lm", font=font, fill="#283e39")
    draw.rectangle((525, 385, 550, 404), fill="#ce5337")
    draw.text((563, 394), "Régression linéaire", anchor="lm", font=font, fill="#283e39")
    image.save(output)



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--metrics", type=Path, default=Path("resultats/metrics.json"))
    parser.add_argument("--output", type=Path, default=Path("erreurs-mensuelles.png"))
    args = parser.parse_args()
    graph(json.loads(args.metrics.read_text(encoding="utf-8")), args.output)

