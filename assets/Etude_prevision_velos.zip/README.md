# Prévision quotidienne des locations de vélos

## Question
Une régression linéaire améliore-t-elle une référence hebdomadaire pour prévoir le total des locations à J+1 ? L’étude est en cours de relecture. Le dossier permet de refaire les calculs et de vérifier les résultats.

## Données et provenance
Fanaee-T, H. et Gama, J. (2013), *Bike Sharing*, UCI Machine Learning Repository.
DOI : https://doi.org/10.24432/C5W894. Licence CC BY 4.0 : https://creativecommons.org/licenses/by/4.0/.
Une copie inchangée de l’archive publique UCI est fournie dans donnees/. Le script lit uniquement le fichier quotidien. Il vérifie 731 dates civiles uniques et continues, l’absence de totaux négatifs et la cohérence avec la somme des locations casual et registered.

## Pour reproduire
Python 3.10+, NumPy et Pillow. Dans le dossier décompressé :

    python3 -m pip install -r requirements.txt
    python3 analyse_velos.py --archive donnees/uci-bike-sharing.zip
    python3 graphique.py

Pour retélécharger l’archive officielle, lancer analyse_velos.py sans l’option --archive. Les CSV, métriques et graphique sont recréés dans le dossier décompressé.

## Méthode
- Cible : total des locations quotidiennes, un jour à l’avance.
- Référence : volume observé le même jour de la semaine précédente.
- Régression linéaire par moindres carrés : constante, tendance temporelle, composantes sinusoïdales annuelles, jour férié, jour de semaine et volumes à J−1, J−7 et J−14. Les prévisions négatives sont ramenées à zéro.
- La météo observée du jour cible et les composantes du total sont exclues. Le volume J−1 doit être disponible à l’heure de la prévision.
- Ajustement sur 2011, validation sur le premier semestre 2012. Nouvel ajustement jusqu’au 30 juin 2012 puis test chronologique sur les 184 jours restants, avec coefficients fixes. L’historique observé est mis à jour chaque jour.
- MAE pour l’erreur typique, RMSE pour les grosses erreurs, biais signé (prédit moins observé) et MAE séparée semaine/week-end.

## Résultat
Sur les 184 jours de test, l’erreur absolue moyenne passe de 1 130 à 869 locations par jour, soit une baisse de 23,1 %. Le RMSE baisse aussi, de 1 648 à 1 193. En août, le repère hebdomadaire reste légèrement meilleur.

## Limites et suite
Les observations sont anciennes et ne couvrent qu’une seule ville. Le total réseau est insuffisant pour décider quelles stations réapprovisionner. Un test sur des données récentes, une comparaison à une moyenne de plusieurs semaines et une mesure de l’apport de prévisions météo archivées seraient nécessaires avant usage opérationnel.

## Fichiers
- analyse_velos.py : ingestion, contrôles, ajustement, évaluation et export.
- resultats/predictions.csv : valeurs observées et prévues par jour de test.
- resultats/metrics.json : métriques des deux périodes, ventilations et erreurs mensuelles.
- graphique.py et erreurs-mensuelles.png : création et rendu du graphique.
- donnees/uci-bike-sharing.zip : archive source UCI inchangée.
